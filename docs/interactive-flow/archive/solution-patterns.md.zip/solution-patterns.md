# Soluzioni tecniche per gestire la conversazione in INTERACTIVE_FLOW

> Panoramica **technique-oriented** (non framework-oriented). Ogni soluzione è un pattern architetturale implementabile nel nostro codebase attuale (TypeScript + Zod + Activepieces + LLM provider con tool/structured output). Baseline di confronto: ciò che abbiamo già **oggi** in produzione.

## 0. Sistema attuale (baseline)

Lo descrivo per esteso così tutto il resto si legge in contrasto.

**Interfaccia LLM ↔ server**:
- Un singolo prompt al LLM per turno
- LLM ritorna un **JSON monolitico**: `{ extractedFields: {...}, turnAffirmed, evidence, metaAnswer? }`
- Schema JSON noto ma non strict (il server fa safeParse Zod in coda)

**Organizzazione lato server**:
- Pre-parser regex (ndg, rapportoId, date) per valori strutturati
- `candidatePolicy` pure-function: admissibility (scope node-local), evidence check, plausibility (regex), domain (enum contro catalog)
- `overwritePolicy` pure-function: cue detection + decide (accept / confirm / reject)
- Dispatcher ad-hoc nell'executor (grande if/else)

**Stato e memoria**:
- `flowState`: Record<string, unknown> con i valori estratti e gli output dei tool
- `executedNodeIds`, `skippedNodeIds`: Set<string>
- Dependency graph per topic-change downstream invalidation (state sì, nodeIds **parzialmente**)
- Session record persistito via `store-entries` API

**Gap ammessi**:
- Nessuna gestione di cancel esplicito
- `metaAnswer` viene generato ma ignorato (non consumato dall'executor)
- Nessuna info-question answering (*"quanti rapporti?"*)
- Compound intent non gestito (*"Rossi, quanti rapporti?"*)
- Nessuna loop prevention su meta/info consecutive

---

## 1. Pattern tecnici per l'interfaccia LLM → business logic

Le tecniche per "come l'LLM comunica al server cosa fare".

### P1 — JSON extraction monolitico (attuale)
**Tecnica**: LLM produce 1 oggetto JSON con tutti i campi noti; server Zod-parse + filtra.

- ✅ Semplice, veloce (1 LLM call, 1 parse)
- ✅ Schema chiaramente versionabile
- ❌ Ogni nuova "cosa" richiede un nuovo campo nel JSON
- ❌ L'LLM mischia intents diversi in un singolo output → parsing ambiguo
- ❌ Nessuna pressione semantica sulla distinzione "ho un valore" vs "voglio fare un'azione"

### P2 — Intent classification (enum discriminated union)
**Tecnica**: LLM produce `{ intent: { type: 'extract'|'meta'|'info'|'cancel'|'affirm'|'deny'|'continue', payload: ... } }`. Dispatcher mappa → handler.

- ✅ Semantica chiara (1 intent per turno)
- ✅ Handler puri, testabili
- ❌ **Mutuo esclusivo**: se utente fa 2 cose (extract + info), si perde una
- ❌ Aggiungere un intent = cambiare schema + nuovo handler
- ❌ L'LLM deve "scegliere" e può sbagliare su turni ambigui

### P3 — Tool-calling nativo (function calling Anthropic/OpenAI)
**Tecnica**: esponi N tool al LLM (schema Zod per ciascuno). L'LLM emette 1-N `tool_call`. Server itera le tool call ed esegue l'handler per ciascuna.

- ✅ **Compound nativo** (LLM emette più tool call in un turno)
- ✅ Evidence obbligatorio come tool parameter (schema strict)
- ✅ Log strutturati: `tool_call(name, args)` leggibile
- ✅ Ogni provider moderno supporta nativamente (Claude, OpenAI, Gemini)
- ❌ Prompt engineering più accurato (definire quando usare ogni tool)
- ❌ L'LLM potrebbe emettere tool call ridondanti o in ordine sbagliato → validation lato server

### P4 — Command DSL testuale
**Tecnica**: LLM ritorna una stringa con "comandi" testuali strutturati, es:
```
set_slot customerName=Rossi evidence="Rossi"
respond_info "17 rapporti" cite=accounts
```
Il server parsa come DSL con grammar dichiarata.

- ✅ Funziona anche con LLM senza tool-calling nativo (ma l'utente ha detto di non considerarli)
- ✅ Più flessibile dei tool call (può emettere comandi custom senza schema prefissato)
- ❌ Parser custom da scrivere e manutenere
- ❌ Grammar ambigua = errori di parsing
- ❌ No type-safety automatica (richiede validator custom)

### P5 — Structured output con JSON schema strict / constrained decoding
**Tecnica**: il LLM è **vincolato** a produrre output conforme a uno schema JSON grazie a strict mode (Claude, OpenAI) o constrained sampling. Lo schema può essere un discriminated union di "azioni" (equivalente ai tool).

- ✅ Garantisce correttezza sintattica output (niente parse error)
- ✅ Più veloce di tool-calling (meno token di framing)
- ❌ Solo strutturato: non è strictly tool-calling, è JSON
- ❌ Provider support: Claude strict mode OK, OpenAI strict OK, altri variabili

### P6 — Programmatic tool calling (sandbox di codice)
**Tecnica**: il LLM scrive **codice** (Python/JS) che chiama i tool. Il server esegue il codice in sandbox. Riduce i round-trip per workflow multi-tool.

- ✅ Latenza molto bassa per workflow con molti tool
- ✅ Logica conditional espressa dall'LLM stesso
- ❌ **Complessità operativa altissima**: serve sandbox secure, audit code
- ❌ Overkill per il nostro DAG (noi abbiamo il flow già strutturato)
- ❌ Compliance difficile in banking (codice generato dal LLM)

---

## 2. Pattern tecnici per organizzare la logica lato server

Come si struttura il dispatch, la policy, la validazione.

### O1 — Policy pure-function layer (attuale)
Funzioni pure (`candidatePolicy.verify*`) che ricevono dati + config e restituiscono `{ok, reason}`. Niente state esterno. Testabili in isolamento.

- ✅ Testability 100%, deterministic
- ✅ Riuso cross-chiamante (chiama dal controller, dall'executor, dal copilot tool set)
- ✅ Già in produzione

### O2 — Handler per discriminated union
Dispatcher semplice: `switch (intent.type) { case 'meta': return metaHandler(ctx) ...`. Ogni handler è una funzione pura.

- ✅ Codice lineare, facile da debuggare
- ✅ Scalabile: + handler per + intent
- ❌ Solo se usi P2 (Intent System)

### O3 — Tool-executor con registry
`registry[toolName](args, ctx)` chiamato in loop sulle tool call emesse dall'LLM. Ogni tool ha il suo handler in un file dedicato.

- ✅ Un handler per tool, isolato
- ✅ Composizione: tool = nome + schema Zod + handler
- ✅ Aggiungere una capacità = + 1 tool (+ 1 handler + 1 entry in registry)
- ❌ Solo se usi P3 (Tool-calling)

### O4 — Dialogue stack per gestione pending
Stack di "pending interaction" (confirm_binary, pending_overwrite, pending_cancel). Turno utente → risolve il top dello stack, eventuale new pending pushato.

- ✅ Scalabile a N tipologie di pending concorrenti
- ✅ Topic change che interrompe un confirm = semplicemente un push sullo stack
- ✅ Pattern collaudato (Rasa, dialog systems anni '90)
- ❌ Complessità se lo stack ha interdipendenze

### O5 — DAG con prompt per-nodo (paper arxiv 2505.23006)
Ogni nodo del flow ha **il proprio system prompt** (incluso in prompt extractor quando currentNode = quel nodo) + una **subset dei tool** disponibili. LLM vede solo le istruzioni rilevanti per lo step corrente.

- ✅ Prompt più corti → accuracy migliore (studio mostra +52% compliance)
- ✅ Isolamento: il nodo "pick_ndg" non riceve istruzioni sul nodo "collect_date"
- ✅ Naturalmente anti-hallucination (meno tentazioni off-topic)
- ❌ Setup iniziale più laborioso (un prompt per nodo)
- ❌ Prompt manutenzione: quando cambi una policy globale tocchi molti file

### O6 — Evaluator-optimizer loop
Dopo ogni turno, un secondo LLM "valuta" se la risposta è coerente con lo state / costraint. Se non lo è, retry.

- ✅ Self-correcting
- ❌ +1 LLM call per turno (latenza + costo raddoppiati)
- ❌ Non-deterministic (test fragili)
- ❌ Overkill per DAG strutturati come i nostri

---

## 3. Pattern tecnici per affidabilità e sicurezza

### S1 — Evidence-bound extraction (attuale)
Ogni valore estratto deve avere un `evidence: string` che è sub-string del messaggio utente (verificato server-side via normalization). Se assente o non matcha → rifiutato.

- ✅ Blocca hallucination: LLM non può inventare un ndg "11255521" senza che sia nel testo
- ✅ Costo: 0 (solo schema + check server)
- ⚠️ Con LLM molto aggressivi, evidence può essere "forced" (LLM inventa una substring vaga) — mitigato da minLen=2

### S2 — Value admissibility / scope check (attuale)
Ogni campo ha `extractionScope: 'global' | 'node-local'`. Il server verifica che un valore venga accettato solo quando il nodo currente è compatibile.

- ✅ Risolve il bug H1 (confirmed non estratto al turno 1)
- ✅ Estendibile (es. `extractionScope: 'after-tool-X'`)

### S3 — Enum validation contro catalog dinamico (attuale)
`enumFrom` + `enumValueField`: il valore viene accettato solo se presente in `state[enumFrom][].enumValueField`.

- ✅ Blocca valori fuori-catalog (ndg non esistente, motivazione inventata)
- ✅ Deferred: se catalog non ancora popolato, accetta tentativamente e rivalida

### S4 — Confidence threshold + fallback
Se l'LLM restituisce confidence basso (score < 0.7), il server chiede conferma invece di applicare.

- ✅ Controllo del rischio per campi critici
- ❌ Non tutti i provider forniscono confidence score — serve un proxy (es. LLM-as-judge)

### S5 — Guardrails layer (pre/post)
Funzioni di guard che filtrano pre-prompt (es. rimuovere PII dal messaggio) e post-output (es. bloccare risposte che contengono numeri non in state).

- ✅ Difesa in profondità per compliance
- ⚠️ Latenza + complessità (+1 LLM call se uso LLM-as-judge)

### S6 — Audit trail strutturato
Ogni azione server-side loggata con reason, evidence, ts, user. Permette replay e debug.

- ✅ Obbligatorio per banking (compliance)
- ✅ Già parziale nel nostro sistema (debug log JSONL)

---

## 4. Pattern tecnici per gestione conversazione

### C1 — Pending interaction (attuale)
`pendingInteraction: { type: 'confirm_binary' | 'pick_from_list' | 'pending_overwrite' }`. Il turno successivo è interpretato nel contesto del pending.

- ✅ Pattern robusto per conferma / selezione / correzione
- ❌ Non include `pending_cancel` attualmente

### C2 — Cue-detected overwrite (attuale)
Se il messaggio contiene cue di correzione (scusa, invece, anzi, wait, sorry), applica senza chiedere. Altrimenti emette pending_overwrite.

- ✅ UX naturale (utente con cue non deve confermare 2 volte)
- ⚠️ Cue list italiana migliorabile (mi scuso, chiedo scusa varianti)

### C3 — Downstream invalidation su topic change (attuale parziale)
Quando un campo cambia, il dependency graph invalida i state fields downstream. **Gap**: non invalida `executedNodeIds` e `skippedNodeIds`.

### C4 — Loop prevention (mancante)
Contatore di meta/info/cancel consecutive. Al N-esimo, il server forza re-prompt del campo mancante invece di rispondere all'ennesima meta.

- Semplice: counter in session + soft nudge nel template risposta
- Costo: 0

### C5 — Meta/info answer reuse (mancante)
Il LLM genera una risposta contestuale alla domanda meta/info; il server la emette come bubble e **non avanza** il flow.

- Richiede: P2 o P3 come interfaccia
- Wiring: dispatcher handler che emette bubble + ripausa

### C6 — Cancel con conferma (mancante)
Tool/intent `requestCancel` → pending_cancel → "Sei sicuro?" → affirm/deny → soft reset state.

- ✅ Coerente con pattern pending esistente
- ✅ Soft-reset è generic (azzera state, mantiene sessionId)

---

## 5. Matrice: quale pattern risolve quale requisito

Incrociando i requisiti di [flows-analysis.md](./flows-analysis.md) §7.1 con i pattern:

| Requisito | Pattern che lo risolve | Già presente? |
|---|---|---|
| F1 — Estrazione campi + catalog validation | P1/P2/P3 + O1 + S1,S2,S3 | ✅ oggi con P1 |
| F2 — Auto-select single option in pick_* | Logica core (indipendente dall'interfaccia LLM) | ✅ oggi |
| F3 — Topic change invalidate downstream | C3 (state) + estendere a executedNodeIds | ⚠️ parziale |
| F4 — No auto-submit batched | S2 (node-local scope) | ✅ oggi (dopo fix) |
| F5 — Meta-question answering | C5 | ❌ metaAnswer ignorato |
| F6 — Info-question answering | C5 + prompt include currentState | ❌ |
| F7 — Cancel con conferma | C6 + C1 esteso | ❌ |
| F8 — Compound intent | **P3 obbligatorio** (P1/P2 non lo supportano) | ❌ |
| F9 — Timeline visibilità | Nuovi socket event kinds (non è un pattern LLM) | ⚠️ parziale |
| F10 — Loop prevention | C4 | ❌ |

**Osservazione forte**: F8 (compound intent) è l'**unico** requisito che discrimina P1/P2 da P3. Tutto il resto è realizzabile con qualsiasi pattern di interfaccia LLM.

---

## 6. Ricette complete (combinazioni di pattern)

Una "soluzione" è una combinazione di 1 pattern della categoria 1 + N pattern della categoria 2,3,4. Ecco le ricette sensate:

### Ricetta R1 — Evoluzione minima dell'attuale
**Pattern**: P1 (JSON monolitico esteso con `userIntent: UserIntent`) + O1 (già) + O2 (nuovo dispatcher) + S1-3 (già) + C1-C6 tutti.

- Mantiene lo schema JSON attuale + aggiunge un campo `userIntent` discriminated union
- Handler dispatch per intent
- Aggiunge D3, D5, D6 (loop prevention, meta/info, cancel)
- **Non** risolve F8 (compound)

**LoC stimate**: ~1200 core + 400 test = 1600 totali
**Rischio**: basso
**Prompt engineering**: medio

### Ricetta R2 — Intent System
**Pattern**: P2 + O2 + S1-3 + C1-C6 tutti.

- Come R1 ma il campo `userIntent` è l'unico output "azione" (niente extractedFields separati)
- Handler pulito per ogni intent
- **Non** risolve F8

**LoC stimate**: ~1500 core + 500 test = 2000 totali
**Rischio**: basso-medio (classifier può sbagliare su ambiguo)
**Prompt engineering**: medio

### Ricetta R3 — Tool-calling Agent
**Pattern**: P3 + O3 + S1-3 (applicati come validation post tool-call) + C1-C6 tutti.

- LLM emette 1-N tool call per turno
- 7 tool nel registry: setStateField, respondMeta, respondInfo, requestOverwrite, requestCancel, acknowledgePending, continueFlow
- **Risolve F8 nativo** (compound = 2 tool call)
- Log strutturati per ogni tool call

**LoC stimate**: ~1800 core + 600 test = 2400 totali
**Rischio**: medio (prompt engineering più delicato)
**Prompt engineering**: alto all'inizio, scalabile

### Ricetta R4 — Tool-calling + prompt per-nodo (paper 2505.23006)
**Pattern**: P3 + O3 + **O5** + S1-3 + C1-C6 tutti.

- Come R3 ma ogni nodo del flow ha il proprio mini system-prompt con solo i tool rilevanti
- Es. al nodo `pick_ndg`: tool `[setStateField.ndg, respondMeta, respondInfo, requestCancel]`. Niente `setStateField.closureDate`.
- Il paper mostra +52% compliance vs baseline

**LoC stimate**: ~2200 core + 700 test = 2900 totali
**Rischio**: medio
**Prompt engineering**: alto (manutenzione prompt per-nodo)
**Accuratezza attesa**: massima

### Ricetta R5 — Structured output strict mode + Intent System
**Pattern**: P5 + O2 + S1-3 + C1-C6 tutti.

- Come R2 ma usa strict mode dell'LLM (Claude/OpenAI) per garantire JSON conforme
- Schema è un discriminated union stretto
- **Non** risolve F8 (schema forza un solo intent)

**LoC stimate**: ~1500 core + 500 test = 2000 totali
**Rischio**: medio (dipende da supporto provider)
**Prompt engineering**: medio
**Affidabilità parsing**: massima

### Ricetta R6 — Tool-calling + Command Stack (dialogue stack)
**Pattern**: P3 + O3 + **O4 (dialogue stack)** + S1-3 + C1-C6 tutti.

- Come R3 ma il pending non è un singolo oggetto, è uno stack LIFO
- Scenario: confirm_binary in corso → utente fa topic change → stack diventa `[confirm_binary, pending_overwrite]`. Risolvi il top prima, poi torni al sottostante.

**LoC stimate**: ~2000 core + 700 test = 2700 totali
**Rischio**: medio
**Gestione conversazioni complesse**: massima

---

## 7. Quale ricetta scegliere per i nostri 2 flow

Incrocio ricette × flow dalla [proposals-comparison.md](./proposals-comparison.md):

| Ricetta | Estinzione | Consultazione | Flow futuri misti |
|---|:---:|:---:|:---:|
| R1 (evoluzione minima) | Eccellente | Buona | Limitata (no compound) |
| R2 (Intent System) | Eccellente | Buona | Limitata (no compound) |
| R3 (Tool-calling) | Eccellente | Eccellente | Eccellente |
| R4 (Tool + per-node prompt) | **Superiore** | **Superiore** | Eccellente |
| R5 (Structured strict) | Eccellente | Buona | Limitata |
| R6 (Tool + dialogue stack) | Eccellente | Eccellente | **Superiore** su scenari complessi (multi-pending concorrenti) |

### Raccomandazione neutra

- Se l'obiettivo è **shipping rapido con rischio minimo** e compound non è critico → **R1** (evoluzione dell'attuale)
- Se l'obiettivo è **qualità massima oggi** sui 2 flow → **R3** (Tool-calling Agent)
- Se vogliamo **accuratezza massima per ogni nodo** (paper arxiv 2505.23006 mostra +52% compliance) → **R4** (Tool + per-node prompt)
- Se prevediamo flow con **pending multipli concorrenti** (es. confirm_binary + cancel insieme) → **R6** (Tool + dialogue stack)

### Il mio voto

**R4 — Tool-calling Agent con prompt per-nodo**. Motivi tecnici:

1. **P3 (tool-calling)** risolve F8 (compound) nativamente. Zero friction per gli operatori reali che pongono domande mentre danno dati.

2. **O5 (prompt per-nodo)** è quello che la ricerca industriale 2025 mostra essere **la singola miglioria con impatto più alto** su accuracy e compliance (paper 2505.23006: +52%). La nostra topologia DAG lo rende naturale: ogni nodo sa già cosa si aspetta dall'LLM in quel contesto.

3. Integra tutti i gap (C4, C5, C6) senza cambiare la forma del pattern.

4. Codebase: ~2900 LoC, di cui ~1100 sono incrementi rispetto a R3. L'aggiunta di prompt-per-nodo è puramente **dati** (un markdown/string per nodo nel fixture), non codice esecutivo.

5. Non richiede framework (restiamo su TypeScript + Zod + provider LLM nostro). Rispetta il tuo vincolo.

**R6 (dialogue stack)** è l'alternativa da considerare **se in futuro** prevediamo interazioni con multipli pending concorrenti. Oggi non ne abbiamo, ma il costo di adottarla ex-post non è enorme (il pending diventa stack invece di scalar).

---

## 8. Cosa aggiungere **sicuramente** alla baseline (indipendente dalla ricetta scelta)

Anche se restiamo su R1 (minimo) o andiamo su R4 (massimo), queste aggiunte sono **sempre** sensate e ortogonali alla scelta principale:

| Aggiunta | Pattern | Impatto |
|---|---|---|
| **Consumo di `metaAnswer`** | C5 | Sblocca F5 senza altro lavoro |
| **`invalidatedNodeIds` in applyStateOverwriteWithTopicChange** | C3 | Completa F3 |
| **Counter meta/info consecutive in session record** | C4 | Sblocca F10 |
| **`pending_cancel` come variant della discriminated union** | C6 + C1 | Sblocca F7 |
| **Esporre gli stateFields `description` nel prompt in modo più strutturato** | O5 (partial) | Migliora accuracy estrazione |

Queste sono **~400 LoC** che si possono fare **prima** di decidere R1/R3/R4. Riempiono il 70% dei gap attuali senza cambiare architettura.

---

## 9. Diagramma decisionale

```
         Serve compound intent?
              │
    ┌─────────┴─────────┐
   NO                  SÌ
    │                   │
    ▼                   ▼
  R1 o R2         P3 obbligatorio
  (JSON/Intent)         │
    │           ┌───────┴────────┐
    │          Serve            Serve pending
    │      max accuracy?       concorrenti?
    │           │                  │
    │     ┌─────┴────┐      ┌──────┴──────┐
    │    NO        SÌ       NO           SÌ
    │    │          │        │            │
    │    ▼          ▼        ▼            ▼
    │   R3          R4       R3          R6
    │ (tool     (tool    (tool-calling  (tool + stack)
    │  basic)  per-node)    base)
```

Per il nostro contesto (2 flow bancari + flow futuri simili): il ramo destro → **R4**.

---

## 10. Pattern NON consigliati per il nostro caso

Lo dico esplicitamente per chiudere la discussione:

- ❌ **P6 Programmatic tool calling**: overkill, complessità sandbox, audit difficile in banking
- ❌ **O6 Evaluator-optimizer loop**: non ci serve (DAG strutturato, non task aperto)
- ❌ **ReAct puro**: non-deterministico, incompatibile con testability in compliance
- ❌ **End-to-end LLM senza DAG**: zero controllo, rischio compliance, documentato worst-case nel paper 2505.23006

---

## 11. Riepilogo esecutivo

| Tema | Scelta minima (sicura) | Scelta consigliata | Scelta massimo |
|---|---|---|---|
| Interfaccia LLM | P1 (mantieni) | **P3 (tool-calling)** | P3 + P5 strict mode |
| Organizzazione server | O1 + O2 | **O3 (tool registry)** | O3 + **O5 per-nodo** |
| Affidabilità | S1-S3 (invariati) | S1-S3 + S6 audit | S1-S3 + S6 + S4 confidence |
| Conversazione | C1-C2 + add C4-C6 | C1-C6 completi | C1-C6 + **O4 stack** |
| Ricetta | R1 | **R4** | R6 |
| LoC totali | ~1600 | **~2900** | ~3500 |
| Rischio | Basso | Medio | Medio-alto |
| Risolve F8 (compound) | ❌ | ✅ | ✅ |
| Compliance max (+52% paper) | ❌ | ✅ (via O5) | ✅ |

## 12. Prossima decisione

Dalla tabella precedente, scegli R1 / R3 / R4 / R6. Una volta deciso, preparo un piano di implementazione dettagliato (file toccati, ordine di commit, test strategy, shadow mode, rollout).

## Fonti

- [Practical Approach for Building Production-Grade Conversational Agents with Workflow Graphs (arxiv 2505.23006)](https://arxiv.org/html/2505.23006v1) — paper su DAG + LLM nodi con prompt per-stato, +52% accuracy
- [Zero-shot Slot Filling in the Age of LLMs (aclanthology 2025)](https://aclanthology.org/2025.coling-industry.59.pdf) — slot-filling con small LLM (10B param) per compliance
- [Anthropic Advanced Tool Use](https://www.anthropic.com/engineering/advanced-tool-use) — Tool Search, Programmatic Tool Calling, Tool Use Examples
- [Anthropic Structured Outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) — strict mode + constrained sampling
- [Workflows vs Agents (LangGraph docs)](https://docs.langchain.com/oss/python/langgraph/workflows-agents) — 5 pattern: chaining, parallelization, routing, orchestrator-worker, evaluator-optimizer
- [Function Calling & Tool Use Complete Guide 2026](https://ofox.ai/blog/function-calling-tool-use-complete-guide-2026/)
